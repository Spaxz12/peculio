# Chef de Bolso

Sugestões de receitas com IA a partir dos ingredientes que já tens em casa —
por texto ou por foto da despensa/frigorífico. Usa a API da Gemini (Google),
que tem um nível gratuito contínuo.

## 1. Cria a tua chave de API da Gemini
1. Vai a https://aistudio.google.com/apikey e entra com uma conta Google.
2. Clica em **"Create API key"**.
3. Escolhe ou cria um projeto Google Cloud quando pedido (é automático, não
   precisas de configurar nada manualmente).
4. Copia a chave gerada.
5. **Não precisas de cartão de crédito** para o nível gratuito. Os limites
   diários variam por modelo e mudam com alguma frequência — confirma os
   valores atuais em https://aistudio.google.com/rate-limit depois de teres
   a tua chave, para saberes quantos pedidos por dia tens disponíveis grátis.

## 2. Testar localmente
```
cp .env.example .env
```
Edita o `.env` e cola a tua chave em `GEMINI_API_KEY`. Depois:
```
npm install
npm start
```
Abre http://localhost:3002 no browser do teu computador para testares.

## 3. Publicar online (para usares no iPhone, de qualquer lado)
1. Cria uma conta grátis em https://render.com (podes usar o GitHub para entrar).
2. Sobe esta pasta para um repositório no GitHub.
3. No Render, escolhe **New → Web Service**, liga o repositório.
4. Configuração:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Environment Variables:** adiciona `GEMINI_API_KEY` com a tua chave,
     e opcionalmente `GEMINI_MODEL` (ex: `gemini-2.5-flash` ou
     `gemini-2.5-flash-lite` para mais pedidos grátis por dia)
5. Cria o serviço. Ao fim de uns minutos, o Render dá-te um endereço tipo
   `https://chef-de-bolso.onrender.com`.

## 4. Instalar no iPhone
1. Abre esse endereço no Safari do iPhone.
2. Toca no ícone de partilhar (quadrado com seta para cima).
3. Escolhe **"Adicionar ao Ecrã Principal"**.
4. Fica com ícone próprio, abre em ecrã inteiro, como uma app normal.

## Notas importantes
- **Plano gratuito do Render "adormece"** o servidor ao fim de uns minutos
  sem uso — o primeiro pedido depois disso demora uns segundos extra a
  responder. É normal, não é erro.
- **Limite diário gratuito da Gemini**: se ultrapassares o limite de pedidos
  do dia, a app mostra um erro a dizer isso — volta a funcionar no dia
  seguinte, ou liga faturação na tua conta Google Cloud para limites bem
  mais altos (continuas a não pagar nada até ultrapassares a quota grátis,
  ligar faturação só aumenta o limite de pedidos por minuto).
- **Os dados da despensa e da lista de compras ficam só no teu iPhone**
  (localStorage do Safari) — não há conta nem sincronização entre
  dispositivos nesta versão.
