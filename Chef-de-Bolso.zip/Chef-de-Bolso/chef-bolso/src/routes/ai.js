const express = require('express');
const rateLimit = require('express-rate-limit');
const { askGeminiForJSON } = require('../lib/gemini');

const router = express.Router();

// Limite generoso mas real — protege a tua chave de API de uso descontrolado
// (ex: alguém a martelar o botão, ou um bug num loop). Ajuda também a ficares
// dentro do limite diário gratuito da Gemini.
const aiLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  limit: 30,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Calma aí — demasiados pedidos num curto espaço de tempo. Espera uns minutos.' }
});
router.use(aiLimiter);

// Recebe uma foto (base64) da despensa/frigorífico e devolve uma lista de
// ingredientes identificados, para o utilizador rever antes de os adicionar.
router.post('/identify-items', async (req, res) => {
  try {
    const { imageBase64, mediaType } = req.body || {};
    if (!imageBase64) return res.status(400).json({ error: 'Falta a imagem.' });
    const allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
    const type = allowedTypes.includes(mediaType) ? mediaType : 'image/jpeg';

    const result = await askGeminiForJSON({
      system: 'És um assistente de cozinha. Olhas para fotos de despensas, frigoríficos ou bancadas e identificas os ingredientes e alimentos visíveis. Responde APENAS com JSON válido.',
      parts: [
        { inline_data: { mime_type: type, data: imageBase64 } },
        { text: 'Identifica os ingredientes e alimentos visíveis nesta imagem. Responde neste formato exato: {"items": ["nome do ingrediente", ...]}. Usa nomes simples em português (ex: "tomate", "leite", "arroz"), um por item, sem quantidades. Se não conseguires identificar nada com confiança, devolve {"items": []}.' }
      ],
      maxTokens: 600
    });

    const items = Array.isArray(result.items) ? result.items.filter(x => typeof x === 'string' && x.trim()).slice(0, 40) : [];
    res.json({ items });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// Recebe a lista de ingredientes disponíveis e devolve sugestões de receitas
// estruturadas, separando o que já tens do que falta comprar.
router.post('/suggest-recipes', async (req, res) => {
  try {
    const { pantryItems, notes } = req.body || {};
    if (!Array.isArray(pantryItems) || !pantryItems.length) {
      return res.status(400).json({ error: 'Indica pelo menos um ingrediente.' });
    }

    const result = await askGeminiForJSON({
      system: 'És um chef de cozinha caseira, prático e criativo. Sugeres receitas que aproveitam ao máximo os ingredientes que a pessoa já tem em casa, minimizando o que é preciso comprar. Respondes sempre em português de Portugal. Responde APENAS com JSON válido.',
      parts: [{
        text: `Ingredientes disponíveis: ${pantryItems.join(', ')}.` +
          (notes ? ` Preferências/restrições: ${notes}.` : '') +
          ` Sugere 3 receitas possíveis, idealmente usando sobretudo o que já está disponível. Responde exatamente neste formato JSON:
{"recipes": [
  {
    "name": "Nome do prato",
    "description": "Uma frase a descrever o prato",
    "prepTime": "20 min",
    "usesFromPantry": ["ingrediente1", "ingrediente2"],
    "missingIngredients": ["ingrediente que falta comprar"],
    "steps": ["Passo 1...", "Passo 2..."]
  }
]}
Ordena as receitas da que usa mais ingredientes disponíveis para a que usa menos. Os "steps" devem ter entre 3 e 7 passos claros e curtos.`
      }],
      maxTokens: 2000
    });

    const recipes = Array.isArray(result.recipes) ? result.recipes : [];
    res.json({ recipes });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

module.exports = router;
