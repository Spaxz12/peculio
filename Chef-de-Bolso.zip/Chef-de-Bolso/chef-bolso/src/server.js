require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');

const aiRoutes = require('./routes/ai');

const app = express();

app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json({ limit: '8mb' })); // fotos em base64 podem pesar

app.get('/api/health', (req, res) => res.json({ ok: true }));
app.use('/api', aiRoutes);
app.use('/api', (req, res) => res.status(404).json({ error: 'Rota de API desconhecida.' }));

// Serve a app (ficheiros dentro de /public) no mesmo endereço da API
app.use(express.static(path.join(__dirname, '..', 'public')));
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Ocorreu um erro no servidor.' });
});

const port = process.env.PORT || 3002;
app.listen(port, () => {
  console.log(`Chef de Bolso a correr em http://localhost:${port}`);
});
