# Termos de Serviço — Pecúlio

**AVISO IMPORTANTE: Este é um rascunho de ponto de partida, não um
documento legal válido.** Não fui escrito nem revisto por um advogado.
Antes de publicares isto ou de teres um único utilizador real, manda este
documento a um advogado para o validar. Isto é especialmente importante
porque o Pecúlio lida com dados financeiros — os requisitos legais podem
ser mais exigentes do que para uma app comum.

---

Última atualização: [DATA]

## 1. Aceitação dos termos
Ao criar uma conta no Pecúlio, aceitas estes termos. Se não concordares,
não uses o serviço.

## 2. O que é o Pecúlio
O Pecúlio é uma ferramenta de gestão financeira pessoal. **Não é um banco,
não é um consultor financeiro licenciado, e não dá aconselhamento
financeiro, fiscal ou de investimento.** As informações e resumos que a
app apresenta são calculados a partir dos dados que introduzes e servem
apenas fins informativos e organizacionais.

## 3. Conta de utilizador
- És responsável por manter a tua palavra-passe segura.
- És responsável pela exatidão dos dados que introduzes.
- Deves ter pelo menos [16/18] anos para criar uma conta.

## 4. Uso aceitável
Não podes usar o Pecúlio para:
- Atividades ilegais
- Tentar aceder a contas de outros utilizadores
- Sobrecarregar ou comprometer a segurança do serviço

## 5. Disponibilidade do serviço
Fazemos um esforço razoável para manter o serviço disponível, mas não
garantimos disponibilidade contínua. [DESCREVER SE HÁ ALGUM SLA / NÍVEL DE
SERVIÇO GARANTIDO, especialmente se for um serviço pago.]

## 6. Limitação de responsabilidade
Na máxima medida permitida por lei, o Pecúlio não é responsável por
decisões financeiras tomadas com base na informação apresentada pela app,
nem por perdas resultantes de indisponibilidade do serviço, perda de
dados, ou erros de cálculo. [ESTA CLÁUSULA PRECISA DE REVISÃO LEGAL
CUIDADOSA — os limites de responsabilidade que podes impor variam por
jurisdição e podem não ser válidos para negligência grave.]

## 7. Cancelamento
Podes apagar a tua conta a qualquer momento em [Definições]. [DESCREVER O
QUE ACONTECE AOS DADOS APÓS O CANCELAMENTO — ver também a Política de
Privacidade.]

Podemos suspender ou encerrar contas que violem estes termos.

## 8. Alterações
Podemos atualizar estes termos. Uso continuado do serviço após alterações
significa aceitação dos novos termos.

## 9. Lei aplicável
Estes termos regem-se pela lei portuguesa. [CONFIRMAR COM UM ADVOGADO O
FORO COMPETENTE PARA DISPUTAS.]

## 10. Contacto
[EMAIL DE CONTACTO]
