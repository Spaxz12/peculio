# Política de Privacidade — Pecúlio

**AVISO IMPORTANTE: Este é um rascunho de ponto de partida, não um
documento legal válido.** Não fui escrito nem revisto por um advogado.
Antes de publicares isto ou de teres um único utilizador real, manda este
documento a um advogado ou jurista especializado em RGPD/proteção de
dados para o validar e adaptar à tua situação concreta (país onde operas,
onde estão os servidores, se processas pagamentos, etc.). Usar isto sem
essa revisão pode deixar-te legalmente exposto.

---

Última atualização: [DATA]

## 1. Quem somos
O Pecúlio é operado por [NOME / EMPRESA], contribuinte [NIF], com sede em
[MORADA]. Para questões sobre privacidade, contacta [EMAIL DE CONTACTO].

## 2. Que dados recolhemos
- **Dados de conta:** email e palavra-passe (a palavra-passe é sempre
  guardada de forma encriptada, nunca em texto legível).
- **Dados financeiros que introduzes:** transações, categorias, contas,
  orçamentos, metas, e quaisquer recibos que anexes. Estes dados são
  fornecidos por ti — não recolhemos dados bancários diretamente.
- **Dados técnicos:** endereço IP e informação do browser, apenas para
  segurança (ex: prevenir ataques) e diagnóstico de erros.

## 3. Para que usamos os dados
- Fornecer o serviço (guardar e sincronizar as tuas finanças entre
  dispositivos).
- Segurança da conta (prevenir acessos não autorizados).
- Comunicações essenciais sobre o serviço (ex: alterações a esta política).

Não vendemos nem partilhamos os teus dados financeiros com terceiros para
fins de publicidade.

## 4. Onde ficam os dados
[DESCREVER: país/servidor onde a base de dados está alojada, e se algum
fornecedor terceiro (ex: serviço de alojamento) tem acesso técnico aos
dados.]

## 5. Os teus direitos (RGPD)
Se estiveres na União Europeia, tens direito a:
- Aceder aos dados que temos sobre ti
- Corrigir dados incorretos
- Apagar a tua conta e todos os dados associados ("direito ao esquecimento")
- Exportar os teus dados num formato legível por máquina (portabilidade)
- Retirar consentimento a qualquer momento

Para exercer estes direitos, contacta [EMAIL DE CONTACTO]. [DESCREVER O
PRAZO DE RESPOSTA E O PROCESSO EXATO.]

## 6. Segurança
Aplicamos medidas técnicas razoáveis para proteger os teus dados
(encriptação de palavras-passe, ligação segura HTTPS, controlo de acesso).
Nenhum sistema é 100% seguro — [DESCREVER O QUE ACONTECE EM CASO DE
VIOLAÇÃO DE DADOS, incluindo o dever de notificar utilizadores e a
autoridade de proteção de dados dentro de 72 horas, conforme o RGPD].

## 7. Retenção de dados
Guardamos os teus dados enquanto a tua conta estiver ativa. Se apagares a
conta, os dados são eliminados no prazo de [X DIAS], exceto quando a lei
exigir retenção mais longa.

## 8. Alterações a esta política
Podemos atualizar esta política. Notificaremos alterações significativas
por email ou através da aplicação.

## 9. Contacto
Dúvidas sobre privacidade: [EMAIL DE CONTACTO]
Autoridade de controlo em Portugal: Comissão Nacional de Proteção de Dados
(CNPD) — www.cnpd.pt
