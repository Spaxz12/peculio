# Pecúlio — Estado atual e o que falta para ser público

## O que fiz agora
1. **Onboarding** — a app mostra um guia rápido de boas-vindas na primeira
   utilização (só aparece se não houver transações ainda).
2. **Backend de sincronização** (`Peculio-Backend.zip`) — API funcional com
   registo, login seguro e guarda de dados por utilizador, pronta para
   deploy. Código testado quanto à sintaxe; não testado em produção real
   porque não tenho acesso à internet neste ambiente para instalar as
   dependências e correr testes ao vivo.
3. **Rascunhos legais** (`Peculio-Legal.zip`) — Política de Privacidade e
   Termos de Serviço, com os pontos que precisam da tua decisão/revisão
   assinalados a maiúsculas. **Não uses isto sem um advogado a rever.**

## O que continua por fazer (por ordem de prioridade, se quiseres avançar)

**Antes de teres o primeiro utilizador externo:**
1. Ligar o frontend a este backend (trocar localStorage por chamadas à API,
   construir o ecrã de login/registo)
2. Pôr o backend a correr num serviço real (Render/Railway/VPS) com HTTPS
3. Um advogado rever os documentos legais
4. Decidir e implementar o modelo de sustentabilidade (grátis, freemium,
   subscrição)

**Antes de escalar para muitos utilizadores:**
5. Testes automatizados no backend
6. Monitorização de erros em produção (ex: Sentry)
7. Migrar de SQLite para Postgres se o volume crescer
8. Verificação de email no registo
9. Auditoria de segurança independente (é uma app financeira — vale a pena)

**Se um dia quiseres ligação direta a bancos:**
10. Isto exige um parceiro Open Banking licenciado (ex: GoCardless/Tink) —
    já tínhamos falado nisto antes. Continua a ser o maior salto de todos.

## O que decidir tu (não é técnico, sou eu a devolver a bola)
- Nome legal do negócio / se vais operar como pessoa singular ou empresa
- Se queres cobrar algo, e quanto
- Em que país alojar os dados (afeta o RGPD e outras leis)
- Se vais aceitar utilizadores fora da UE (traz outras obrigações legais)
