@echo off
title Peculio
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Iniciar-Peculio.ps1"
pause
