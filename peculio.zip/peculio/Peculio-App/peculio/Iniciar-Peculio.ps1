$folder = Split-Path -Parent $MyInvocation.MyCommand.Path
$port = 8080
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://localhost:$port/")

try {
    $listener.Start()
} catch {
    Write-Host "Não foi possível iniciar na porta $port. Fecha outros programas que a possam estar a usar e tenta novamente."
    Read-Host "Prime Enter para sair"
    exit
}

Write-Host "Pecúlio está a correr em http://localhost:$port"
Write-Host "Deixa esta janela aberta enquanto usas a app."
Write-Host "Para instalar como aplicação: no Edge ou Chrome, clica no icone de instalar na barra de endereco."
Write-Host ""
Write-Host "Para fechar, fecha esta janela ou prime Ctrl+C."

Start-Process "http://localhost:$port/index.html"

while ($listener.IsListening) {
    try {
        $context = $listener.GetContext()
    } catch { break }

    $request = $context.Request
    $response = $context.Response
    $path = $request.Url.LocalPath.TrimStart('/')
    if ($path -eq '') { $path = 'index.html' }
    $filePath = Join-Path $folder $path

    if (Test-Path $filePath -PathType Leaf) {
        $content = [System.IO.File]::ReadAllBytes($filePath)
        $ext = [System.IO.Path]::GetExtension($filePath).ToLower()
        $contentType = switch ($ext) {
            '.html' { 'text/html; charset=utf-8' }
            '.json' { 'application/json' }
            '.js'   { 'application/javascript' }
            '.png'  { 'image/png' }
            '.ico'  { 'image/x-icon' }
            default { 'application/octet-stream' }
        }
        $response.ContentType = $contentType
        $response.ContentLength64 = $content.Length
        $response.OutputStream.Write($content, 0, $content.Length)
    } else {
        $response.StatusCode = 404
    }
    $response.OutputStream.Close()
}
