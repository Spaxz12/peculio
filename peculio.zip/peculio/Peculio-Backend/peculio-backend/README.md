# Pecúlio — API de sincronização

Este é o backend que falta para o Pecúlio deixar de ser "uma app por
computador" e passar a sincronizar dados entre dispositivos, com contas de
utilizador reais. É código-fonte para tu correres — eu não consigo alojar
isto por ti a partir daqui.

## Como ligar tudo, do zero
1. Põe este servidor a correr (localmente para testar, ou num serviço como
   o Render — ver secção "Como pôr isto online a sério" mais abaixo).
2. Confirma o endereço onde ele está acessível (ex: `http://localhost:3001`
   em teste, ou `https://o-teu-nome.onrender.com` em produção).
3. Abre o Pecúlio (o `Peculio.html` ou a app instalada) → **Definições** →
   **Sincronização na nuvem** → **Criar conta**.
4. Cola aí o endereço do servidor, escolhe um email e palavra-passe.
5. Pronto — a partir daqui, a app envia os dados para o servidor sozinha
   uns segundos depois de cada alteração. Noutro computador, repete o
   passo 3 mas com **Iniciar sessão**, e usa "Trazer da nuvem" para
   carregar os dados guardados.

## O que já está feito
- Registo e login com palavra-passe encriptada (bcrypt, nunca guardada em texto)
- Sessões com token (JWT), válidas por 30 dias
- Limite de tentativas de login/registo (proteção contra ataques de força bruta)
- Guardar e ler o estado completo de um utilizador (`GET/PUT /api/state`)
- **Dados guardados num ficheiro JSON simples** (`peculio-data.json`), sem
  nenhuma dependência que precise de compilar código nativo — evita os
  problemas de "Visual Studio Build Tools em falta" no Windows. Para o
  número de utilizadores de um projeto pessoal ou pequeno, isto é mais do
  que suficiente.
- **O frontend do Pecúlio já fala com esta API.** Em Definições → Sincronização
  na nuvem, dá para criar conta, iniciar sessão, enviar/trazer dados e
  terminar sessão. Só precisas de pôr este servidor a correr algures e
  colar o endereço nessa tela.
- **Ligação real ao banco (Open Banking, via Enable Banking).** Depois de
  registares uma aplicação em https://enablebanking.com/cp/applications e
  preencheres as variáveis `ENABLEBANKING_*` no `.env`, em Definições →
  Ligação ao banco a app deixa escolher o banco, abre o site do banco numa
  nova aba para autorizares o acesso, e depois consegues importar
  automaticamente saldo e movimentos — passam pela mesma pré-visualização
  e categorização automática já usada na importação de CSV.

## O que NÃO está feito (e é importante saberes)
- **Sem verificação de email.** Qualquer email é aceite sem confirmação.
- **Sincronização "tudo ou nada", e controlada por ti.** Não há sincronização
  automática silenciosa entre dispositivos ao mesmo tempo — cada vez que
  quiseres trazer os dados mais recentes de outro dispositivo, usas o botão
  "Trazer da nuvem" (e confirmas, porque substitui o que está aqui). Isto
  evita perderes dados por acidente, mas significa que tens de sincronizar
  manualmente quando trocas de computador. Envios para a nuvem acontecem
  sozinhos, cerca de 2 segundos depois de cada alteração, sempre que
  tiveres sessão iniciada.
- **Sem HTTPS incluído.** Em produção, o serviço onde alojares isto (Render,
  Railway, etc.) normalmente trata disso por ti — mas confirma sempre.
  Sem HTTPS, o browser pode bloquear os pedidos vindos de uma app aberta
  em HTTPS (ex: publicada como PWA) para uma API em HTTP simples.

## Como testar localmente
```
cp .env.example .env
# edita o .env e define um JWT_SECRET aleatório (o ficheiro explica como gerar um)
npm install
npm start
```
A API fica em `http://localhost:3001`. Testa com:
```
curl -X POST http://localhost:3001/api/auth/signup -H "Content-Type: application/json" -d "{\"email\":\"tu@exemplo.com\",\"password\":\"palavra-passe-longa\"}"
```

## Ligar ao banco (opcional)
1. Regista uma aplicação em https://enablebanking.com/cp/applications
   (ambiente Sandbox para testar, Production quando quiseres dados reais).
2. Guarda o ficheiro `.pem` (chave privada) descarregado nesta pasta
   (`peculio-backend`).
3. No `.env`, preenche:
   - `ENABLEBANKING_APP_ID` — o ID mostrado depois de registares a aplicação
   - `ENABLEBANKING_PRIVATE_KEY_PATH` — o nome do ficheiro `.pem`
   - `ENABLEBANKING_REDIRECT_URL` — tem de ser exatamente igual ao que
     puseste em "Allowed redirect URLs" no registo (ex:
     `http://localhost:3001/api/bank/callback`)
4. Reinicia o servidor (`npm start`). Em Definições → Ligação ao banco na
   app, já dá para ligar.

Nota: em ambiente **Sandbox**, os bancos disponíveis são simulados (dados
de teste, não a tua conta real). Para ligares a tua conta real, terás de
pedir acesso Production/Restricted à Enable Banking — os passos exatos
estão na documentação deles.

## Como pôr isto online a sério
Não consigo fazer isto por ti, mas os caminhos mais simples e baratos para
um projeto pequeno são:
- **Render.com** ou **Railway.app** — ligas o repositório, defines as
  variáveis de ambiente do `.env`, e eles tratam do HTTPS e do domínio.
  Têm planos gratuitos ou muito baratos para começar.
- Um **VPS barato** (ex: Hetzner, DigitalOcean) se quiseres controlo total —
  mais barato a longo prazo, mas tens de gerir tudo (atualizações de
  segurança, backups, HTTPS com Let's Encrypt).

Nota sobre os dados: ficam num único ficheiro (`peculio-data.json`). Isto é
ótimo para começar, mas a maioria destes serviços apaga o disco a cada
deploy — vais precisar de um "disco persistente" (o Render e o Railway
oferecem isto) para o ficheiro não desaparecer sempre que atualizares o
código. Se um dia cresceres muito, migra para uma base de dados a sério
como Postgres.
