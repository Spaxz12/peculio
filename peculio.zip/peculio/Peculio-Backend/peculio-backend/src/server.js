require('dotenv').config();
const express = require('express');
const cors = require('cors');

const authRoutes = require('./routes/auth');
const dataRoutes = require('./routes/data');
const bankRoutes = require('./routes/bank');

const app = express();

app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json({ limit: '5mb' }));

app.get('/api/health', (req, res) => res.json({ ok: true }));
app.use('/api/auth', authRoutes);
app.use('/api/bank', bankRoutes);
app.use('/api', dataRoutes);

// Handler de erros genérico — nunca expõe detalhes internos ao cliente
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: 'Ocorreu um erro no servidor.' });
});

const port = process.env.PORT || 3001;
app.listen(port, () => {
  console.log(`Pecúlio API a correr em http://localhost:${port}`);
});
