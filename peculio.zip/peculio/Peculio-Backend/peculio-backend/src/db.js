const fs = require('fs');
const path = require('path');
require('dotenv').config();

// Base de dados simples em ficheiro JSON — sem dependências nativas, sem
// necessidade de ferramentas de compilação (Visual Studio, Python, etc.).
// Suficiente para um projeto pessoal ou pequeno. Se um dia tiveres muitos
// utilizadores em simultâneo, migra para Postgres.

const DB_PATH = process.env.DB_PATH || path.join(__dirname, '..', 'peculio-data.json');

function loadDb() {
  if (!fs.existsSync(DB_PATH)) {
    return { nextUserId: 1, users: [], state: {} };
  }
  try {
    return JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
  } catch (e) {
    console.error('Base de dados corrompida ou ilegível, a começar do zero:', e.message);
    return { nextUserId: 1, users: [], state: {} };
  }
}

let db = loadDb();

function persist() {
  // Escreve para um ficheiro temporário e só depois substitui o definitivo,
  // para nunca ficar com um ficheiro a meio escrever se algo falhar.
  const tmpPath = DB_PATH + '.tmp';
  fs.writeFileSync(tmpPath, JSON.stringify(db), 'utf8');
  fs.renameSync(tmpPath, DB_PATH);
}

function findUserByEmail(email) {
  return db.users.find(u => u.email === email) || null;
}

function findUserById(id) {
  return db.users.find(u => u.id === id) || null;
}

function createUser(email, passwordHash) {
  const id = db.nextUserId++;
  db.users.push({ id, email, password_hash: passwordHash, created_at: new Date().toISOString() });
  db.state[id] = null;
  persist();
  return id;
}

function getState(userId) {
  return Object.prototype.hasOwnProperty.call(db.state, userId) ? db.state[userId] : null;
}

function setState(userId, dataObj) {
  db.state[userId] = dataObj;
  persist();
}

function getBankSessions(userId) {
  if (!db.bankSessions) return [];
  const val = db.bankSessions[userId];
  if (!val) return [];
  return Array.isArray(val) ? val : [val]; // compatibilidade com o formato antigo (uma só sessão)
}

function addBankSession(userId, sessionObj) {
  if (!db.bankSessions) db.bankSessions = {};
  const list = getBankSessions(userId);
  list.push(sessionObj);
  db.bankSessions[userId] = list;
  persist();
}

function removeBankSession(userId, sessionId) {
  if (!db.bankSessions) return;
  const list = getBankSessions(userId).filter(s => s.session_id !== sessionId);
  db.bankSessions[userId] = list;
  persist();
}

module.exports = { findUserByEmail, findUserById, createUser, getState, setState, getBankSessions, addBankSession, removeBankSession };

