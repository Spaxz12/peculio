const express = require('express');
const crypto = require('crypto');
const db = require('../db');
const { ebRequest } = require('../lib/enablebanking');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// Guarda temporariamente a correspondência "state" → utilizador, enquanto o
// PSU está no site do banco a autorizar o acesso. Vive só em memória porque
// dura poucos minutos — se o servidor reiniciar a meio, o utilizador só
// precisa de tentar ligar de novo.
const pendingStates = new Map(); // state -> { userId, expiresAt }

function rememberState(userId) {
  const state = crypto.randomUUID();
  pendingStates.set(state, { userId, expiresAt: Date.now() + 15 * 60 * 1000 });
  return state;
}
function consumeState(state) {
  const entry = pendingStates.get(state);
  if (!entry) return null;
  pendingStates.delete(state);
  if (entry.expiresAt < Date.now()) return null;
  return entry.userId;
}

// Encontra a sessão (de entre todas as ligações do utilizador) que contém
// uma determinada conta, pelo seu uid
function findSessionForAccount(userId, uid) {
  const sessions = db.getBankSessions(userId);
  return sessions.find(s => s.accounts.some(a => a.uid === uid)) || null;
}

// Lista de bancos disponíveis num país (por omissão, Portugal)
router.get('/aspsps', requireAuth, async (req, res) => {
  try {
    const country = req.query.country || 'PT';
    const data = await ebRequest(`/aspsps?country=${encodeURIComponent(country)}`);
    const simplified = (data.aspsps || []).map(a => ({ name: a.name, country: a.country, logo: a.logo, bic: a.bic }));
    res.json({ aspsps: simplified });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// Inicia a ligação: devolve o URL do banco para onde o utilizador deve ser
// enviado (a app abre isto numa nova aba). Podes chamar isto várias vezes
// para ligares vários bancos diferentes — cada ligação fica guardada à parte.
router.post('/connect', requireAuth, async (req, res) => {
  try {
    const { aspspName, aspspCountry } = req.body || {};
    if (!aspspName || !aspspCountry) {
      return res.status(400).json({ error: 'Falta indicar o banco (aspspName/aspspCountry).' });
    }
    const redirectUrl = process.env.ENABLEBANKING_REDIRECT_URL;
    if (!redirectUrl) return res.status(500).json({ error: 'ENABLEBANKING_REDIRECT_URL não está definido no .env' });

    const state = rememberState(req.userId);
    const validUntil = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString(); // 90 dias, máximo comum PSD2

    const data = await ebRequest('/auth', 'POST', {
      access: { valid_until: validUntil },
      aspsp: { name: aspspName, country: aspspCountry },
      state,
      redirect_url: redirectUrl,
      psu_type: 'personal'
    });

    res.json({ url: data.url });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// O banco reencaminha o utilizador para aqui depois do login/autorização.
// Isto é uma navegação normal do browser, não um fetch — por isso devolve
// uma página HTML simples, e identifica o utilizador pelo "state", já que
// não há forma de enviar o token de sessão da Pecúlio nesta navegação.
router.get('/callback', async (req, res) => {
  const { code, state, error, error_description } = req.query;
  const userId = state ? consumeState(state) : null;

  function page(title, message, ok) {
    res.set('Content-Type', 'text/html; charset=utf-8');
    res.send(`<!DOCTYPE html><html lang="pt-PT"><head><meta charset="utf-8"><title>${title}</title>
      <style>body{font-family:sans-serif;background:${ok ? '#E7F1EB' : '#F5E7E2'};display:flex;align-items:center;justify-content:center;height:100vh;margin:0;}
      .box{background:#fff;padding:32px 40px;border-radius:12px;max-width:420px;text-align:center;box-shadow:0 4px 20px rgba(0,0,0,0.08);}
      h1{font-size:18px;margin:0 0 10px;}p{color:#555;font-size:14px;line-height:1.5;}</style></head>
      <body><div class="box"><h1>${title}</h1><p>${message}</p></div></body></html>`);
  }

  if (error) {
    return page('Ligação cancelada', error_description || 'O processo de autorização não foi concluído. Podes fechar esta janela e tentar novamente.', false);
  }
  if (!userId || !code) {
    return page('Não foi possível confirmar', 'Esta ligação expirou ou é inválida. Volta à app e tenta ligar ao banco outra vez.', false);
  }

  try {
    const session = await ebRequest('/sessions', 'POST', { code });
    db.addBankSession(userId, {
      session_id: session.session_id,
      accounts: (session.accounts || []).map(a => ({
        uid: a.uid, name: a.name || a.product || 'Conta', currency: a.currency, cash_account_type: a.cash_account_type
      })),
      aspsp: session.aspsp,
      connectedAt: new Date().toISOString()
    });
    page('Conta ligada com sucesso', 'Já podes fechar esta janela e voltar à app Pecúlio para importares os movimentos. Podes repetir este processo para ligares mais bancos, um de cada vez.', true);
  } catch (err) {
    page('Falha ao concluir a ligação', err.message, false);
  }
});

// Estado atual de TODAS as ligações bancárias do utilizador
router.get('/status', requireAuth, (req, res) => {
  const sessions = db.getBankSessions(req.userId);
  res.json({
    connected: sessions.length > 0,
    banks: sessions.map(s => ({
      session_id: s.session_id, aspsp: s.aspsp, connectedAt: s.connectedAt, accounts: s.accounts
    }))
  });
});

// Saldo real da conta, diretamente do banco (não depende de somar transações)
router.get('/accounts/:uid/balance', requireAuth, async (req, res) => {
  try {
    const session = findSessionForAccount(req.userId, req.params.uid);
    if (!session) return res.status(403).json({ error: 'Essa conta não pertence a nenhuma das tuas ligações atuais.' });

    const data = await ebRequest(`/accounts/${req.params.uid}/balances`);
    const balances = data.balances || [];
    // Preferência: saldo contabilístico fechado > saldo instantâneo > disponível provisório > o que houver
    const preferredOrder = ['CLBD', 'XPCD', 'ITAV', 'CLAV', 'ITBD', 'OPBD'];
    let chosen = null;
    for (const type of preferredOrder) {
      chosen = balances.find(b => b.balance_type === type);
      if (chosen) break;
    }
    if (!chosen) chosen = balances[0];
    if (!chosen) return res.status(404).json({ error: 'O banco não devolveu nenhum saldo para esta conta.' });

    res.json({ amount: parseFloat(chosen.balance_amount.amount), currency: chosen.balance_amount.currency, type: chosen.balance_type });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// Movimentos de uma conta bancária ligada, já num formato simples que a app
// consegue importar com a mesma lógica usada para o CSV do banco
router.get('/accounts/:uid/transactions', requireAuth, async (req, res) => {
  try {
    const session = findSessionForAccount(req.userId, req.params.uid);
    if (!session) return res.status(403).json({ error: 'Essa conta não pertence a nenhuma das tuas ligações atuais.' });

    const params = new URLSearchParams();
    if (req.query.date_from) params.set('date_from', req.query.date_from);
    if (req.query.date_to) params.set('date_to', req.query.date_to);
    const qs = params.toString() ? `?${params.toString()}` : '';

    const data = await ebRequest(`/accounts/${req.params.uid}/transactions${qs}`);
    const simplified = (data.transactions || []).map(t => ({
      date: t.booking_date || t.value_date || t.transaction_date,
      description: (t.remittance_information && t.remittance_information.join(' ')) ||
                    (t.creditor && t.creditor.name) || (t.debtor && t.debtor.name) || 'Movimento bancário',
      amount: t.credit_debit_indicator === 'DBIT' ? -Math.abs(parseFloat(t.transaction_amount.amount)) : Math.abs(parseFloat(t.transaction_amount.amount)),
      currency: t.transaction_amount.currency
    })).filter(t => t.date);

    res.json({ transactions: simplified, continuation_key: data.continuation_key || null });
  } catch (err) {
    res.status(err.status || 500).json({ error: err.message });
  }
});

// Termina UMA ligação específica (fecha a sessão do lado da Enable Banking também)
router.delete('/disconnect/:sessionId', requireAuth, async (req, res) => {
  const sessions = db.getBankSessions(req.userId);
  const session = sessions.find(s => s.session_id === req.params.sessionId);
  if (session) {
    try { await ebRequest(`/sessions/${session.session_id}`, 'DELETE'); } catch (e) { /* ignora falha ao revogar */ }
  }
  db.removeBankSession(req.userId, req.params.sessionId);
  res.json({ ok: true });
});

module.exports = router;
