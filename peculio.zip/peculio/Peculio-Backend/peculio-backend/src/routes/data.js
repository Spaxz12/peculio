const express = require('express');
const db = require('../db');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

const MAX_PAYLOAD_CHARS = 4 * 1024 * 1024; // 4MB de margem — os recibos em base64 podem pesar

// Devolve o estado guardado do utilizador (ou null se ainda não sincronizou nada)
router.get('/state', requireAuth, (req, res) => {
  const data = db.getState(req.userId);
  res.json({ data, updatedAt: data ? new Date().toISOString() : null });
});

// Substitui o estado do utilizador pelo objeto completo enviado (sincronização "tudo de uma vez")
router.put('/state', requireAuth, (req, res) => {
  const payload = req.body;
  if (!payload || typeof payload !== 'object') {
    return res.status(400).json({ error: 'Corpo do pedido inválido.' });
  }
  if (JSON.stringify(payload).length > MAX_PAYLOAD_CHARS) {
    return res.status(413).json({ error: 'Os dados são demasiado grandes para sincronizar.' });
  }

  db.setState(req.userId, payload);
  res.json({ ok: true, updatedAt: new Date().toISOString() });
});

module.exports = router;
