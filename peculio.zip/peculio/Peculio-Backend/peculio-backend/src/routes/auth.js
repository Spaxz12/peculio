const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const db = require('../db');

const router = express.Router();

// No máximo 10 tentativas por IP a cada 15 minutos — trava ataques de força bruta
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Demasiadas tentativas. Espera uns minutos e tenta novamente.' }
});

function isValidEmail(email) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function issueToken(userId) {
  return jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: '30d' });
}

router.post('/signup', authLimiter, (req, res) => {
  const { email, password } = req.body || {};

  if (!email || !isValidEmail(email)) {
    return res.status(400).json({ error: 'Indica um email válido.' });
  }
  if (!password || password.length < 8) {
    return res.status(400).json({ error: 'A palavra-passe tem de ter pelo menos 8 caracteres.' });
  }

  const normalizedEmail = email.toLowerCase();
  if (db.findUserByEmail(normalizedEmail)) {
    return res.status(409).json({ error: 'Já existe uma conta com este email.' });
  }

  const passwordHash = bcrypt.hashSync(password, 12);
  const userId = db.createUser(normalizedEmail, passwordHash);

  res.status(201).json({ token: issueToken(userId), email: normalizedEmail });
});

router.post('/login', authLimiter, (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) {
    return res.status(400).json({ error: 'Indica email e palavra-passe.' });
  }

  const user = db.findUserByEmail(email.toLowerCase());
  // Mensagem genérica de propósito — não revela se foi o email ou a palavra-passe que falhou
  if (!user || !bcrypt.compareSync(password, user.password_hash)) {
    return res.status(401).json({ error: 'Email ou palavra-passe incorretos.' });
  }

  res.json({ token: issueToken(user.id), email: user.email });
});

module.exports = router;
